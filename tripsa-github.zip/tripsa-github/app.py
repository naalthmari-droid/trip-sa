"""
TRIPSA - Smart Tourism Recommendation System for Saudi Arabia
Streamlit Application
"""
import streamlit as st
import pandas as pd
import math
import os
import io
from fpdf import FPDF
import arabic_reshaper
from bidi.algorithm import get_display

# ============================================================
# اعدادات الصفحة
# ============================================================
st.set_page_config(
    page_title="TRIPSA - Trip Planner",
    page_icon="🗺️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================
# تنسيق CSS مخصص
# ============================================================
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Tajawal', sans-serif;
    }

    .main-header {
        background: linear-gradient(135deg, #0A1628 0%, #1B4F72 100%);
        padding: 2rem;
        border-radius: 12px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }

    .main-header h1 {
        color: #D4A574;
        font-size: 2.5rem;
        margin-bottom: 0.5rem;
    }

    .main-header p {
        color: #B0C4DE;
        font-size: 1.1rem;
    }

    .day-card {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        border-left: 4px solid #1B4F72;
    }

    .transport-banner {
        background: linear-gradient(90deg, #2980B9, #3498DB);
        color: white;
        padding: 0.8rem 1.2rem;
        border-radius: 8px;
        margin-bottom: 0.8rem;
        font-size: 0.95rem;
    }

    .hotel-card {
        background: #FFF8F0;
        border: 1px solid #D4A574;
        border-radius: 8px;
        padding: 1rem;
        margin-top: 0.8rem;
    }

    .metric-card {
        background: white;
        border-radius: 10px;
        padding: 1.2rem;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    }

    .stSelectbox label, .stRadio label, .stMultiSelect label {
        font-weight: 600;
        font-size: 1rem;
    }

    .lunch-break {
        background: #FFF3E0;
        border: 1px dashed #FF9800;
        border-radius: 6px;
        padding: 0.5rem 1rem;
        margin: 0.3rem 0;
        text-align: center;
        font-size: 0.9rem;
        color: #E65100;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================
# تحميل البيانات (cached)
# ============================================================
@st.cache_data
def load_data():
    base_path = os.path.dirname(os.path.abspath(__file__))
    parent_path = os.path.dirname(base_path)

    # المعالم السياحية
    attr_path = os.path.join(parent_path, 'demo_attractions.xlsx')
    df_attractions = pd.read_excel(attr_path)
    df_attractions.columns = ['idx', 'name', 'city', 'category', 'lat', 'lon', 'url']
    df_attractions['city'] = df_attractions['city'].str.strip()

    # الفنادق
    hotel_path = os.path.join(parent_path, 'booking_saudi_accommodations_final.xlsx')
    df_hotels = pd.read_excel(hotel_path)

    city_ar_en = {
        'أبها': 'Aseer', 'الرياض': 'Riyadh', 'جدة': 'Jeddah', 'مكة المكرمة': 'Makkah',
        'المدينة المنورة': 'Madinah', 'الدمام': 'Eastern Province', 'الخبر': 'Eastern Province',
        'الطائف': 'Taif', 'تبوك': 'Tabuk', 'ينبع': 'Yanbu', 'حائل': 'Hail',
        'العلا': 'AlUla', 'الأحساء': 'Al Ahsa', 'الباحة': 'Al Baha', 'جازان': 'Jazan',
        'نجران': 'Najran', 'القصيم': 'Qassim', 'بريدة': 'Qassim', 'الجبيل': 'Al Jubail',
        'خميس مشيط': 'Aseer', 'الدرعية': 'Riyadh', 'الظهران': 'Eastern Province',
        'مدينة الملك عبدالله الاقتصادية': 'KAEC',
    }

    df_hotels = df_hotels.rename(columns={
        'اسم مكان الإقامة': 'hotel_name', 'المدينة / المنطقة': 'city_ar',
        'نوع الإقامة': 'property_type', 'تصنيف النجوم': 'stars',
        'درجة التقييم (من 10)': 'review_score', 'عدد التقييمات': 'review_count',
        'السعر لليلة الواحدة (SAR)': 'price_sar',
    })
    df_hotels['city_en'] = df_hotels['city_ar'].map(city_ar_en).fillna('Other')
    df_hotels['price_sar'] = pd.to_numeric(df_hotels['price_sar'], errors='coerce').fillna(0)
    df_hotels['review_score'] = pd.to_numeric(df_hotels['review_score'], errors='coerce').fillna(0)

    return df_attractions, df_hotels

df_attractions, df_hotels = load_data()

# ============================================================
# قواعد بيانات ثابتة
# ============================================================
CITY_TO_ATTR = {
    'Riyadh': ['Riyadh', 'Diriyah'], 'Jeddah': ['Jeddah'], 'AlUla': ['AlUla'],
    'Eastern Province': ['Eastern Province'], 'Makkah': ['Makkah'], 'Madinah': ['Madinah'],
    'Tabuk': ['Tabuk'], 'Aseer': ['Aseer'], 'Taif': ['Taif'], 'Hail': ['Hail'],
    'Al Ahsa': ['Al Ahsa'], 'Yanbu': ['Yanbu'], 'Al Baha': ['Al Baha'],
    'Jazan': ['Jazan'], 'Najran': ['Najran'], 'Qassim': ['Qassim'],
    'Al Jubail': ['Al Jubail'], 'KAEC': ['KAEC'], 'The Red Sea': ['The Red Sea'],
}

CITY_COORDS = {
    'Riyadh': (24.7136, 46.6753), 'Jeddah': (21.4858, 39.1925),
    'Makkah': (21.3891, 39.8579), 'Madinah': (24.4672, 39.6024),
    'Eastern Province': (26.3927, 50.1146), 'AlUla': (26.6174, 37.9159),
    'Taif': (21.2703, 40.4158), 'Tabuk': (28.3835, 36.5662),
    'Aseer': (18.2164, 42.5053), 'Hail': (27.5114, 41.7208),
    'Al Ahsa': (25.3494, 49.5876), 'Yanbu': (24.0895, 38.0618),
    'Al Baha': (20.0000, 41.4667), 'Jazan': (16.8893, 42.5611),
    'Najran': (17.4922, 44.1277), 'Qassim': (26.3267, 43.9717),
    'Al Jubail': (27.0046, 49.6225), 'KAEC': (22.4547, 39.1069),
    'The Red Sea': (22.5600, 38.8000),
}

TRANSPORT_DB = {
    ('Riyadh','Jeddah'): {'mode':'Plane','duration':'1h 45m','distance_km':949},
    ('Riyadh','Makkah'): {'mode':'Plane','duration':'1h 50m','distance_km':870},
    ('Riyadh','Madinah'): {'mode':'Plane','duration':'1h 30m','distance_km':848},
    ('Riyadh','Eastern Province'): {'mode':'Car','duration':'4h','distance_km':400},
    ('Riyadh','Qassim'): {'mode':'Car','duration':'3h 15m','distance_km':360},
    ('Riyadh','Hail'): {'mode':'Car','duration':'5h 30m','distance_km':640},
    ('Riyadh','Aseer'): {'mode':'Plane','duration':'1h 40m','distance_km':950},
    ('Riyadh','AlUla'): {'mode':'Plane','duration':'1h 30m','distance_km':800},
    ('Riyadh','Tabuk'): {'mode':'Plane','duration':'1h 45m','distance_km':1200},
    ('Jeddah','Makkah'): {'mode':'Car','duration':'1h','distance_km':80},
    ('Jeddah','Madinah'): {'mode':'Train','duration':'2h 30m','distance_km':450},
    ('Jeddah','Taif'): {'mode':'Car','duration':'1h 45m','distance_km':170},
    ('Jeddah','Yanbu'): {'mode':'Car','duration':'3h 15m','distance_km':325},
    ('Jeddah','AlUla'): {'mode':'Plane','duration':'1h 15m','distance_km':650},
    ('Makkah','Madinah'): {'mode':'Train','duration':'2h 30m','distance_km':450},
    ('Madinah','AlUla'): {'mode':'Car','duration':'3h 30m','distance_km':350},
    ('Madinah','Tabuk'): {'mode':'Car','duration':'5h','distance_km':600},
    ('Madinah','Yanbu'): {'mode':'Car','duration':'2h 30m','distance_km':240},
    ('Eastern Province','Al Ahsa'): {'mode':'Car','duration':'1h 30m','distance_km':150},
    ('Eastern Province','Al Jubail'): {'mode':'Car','duration':'1h 15m','distance_km':100},
    ('Aseer','Al Baha'): {'mode':'Car','duration':'2h 30m','distance_km':250},
    ('Aseer','Jazan'): {'mode':'Car','duration':'3h','distance_km':300},
    ('Aseer','Najran'): {'mode':'Car','duration':'3h 30m','distance_km':350},
}

AVAILABLE_CITIES = sorted(CITY_TO_ATTR.keys())

# تصنيف النشاطات حسب المدة المطلوبة (بالدقائق)
ACTIVITY_DURATION = {
    'Museum': 150, 'Culture & History': 150, 'Historic site': 120,
    'Architectural sites': 120, 'Religious Site': 90, 'Mosques': 60,
    'Nature': 120, 'Mountains': 180, 'Natural site': 120, 'Farm': 90,
    'Adventure': 150, 'Sports': 120,
    'Entertainment': 90, 'Amusement parks': 180, 'Cinema': 120,
    'Public Park': 90, 'Libraries': 60,
    'Shopping': 90, 'Traditional Market': 120,
    'Food & Beverages': 75, 'Restaurant': 75,
    'International Kitchen': 75, 'Italian Kitchen': 75, 'Asian Kitchen': 75,
    'Art Gallery': 90, 'Families': 90,
    'Classes and Training': 120, 'Accommodations': 60,
}

def get_transport(city_a, city_b):
    key1, key2 = (city_a, city_b), (city_b, city_a)
    if key1 in TRANSPORT_DB:
        return TRANSPORT_DB[key1]
    if key2 in TRANSPORT_DB:
        return TRANSPORT_DB[key2]
    c1, c2 = CITY_COORDS.get(city_a), CITY_COORDS.get(city_b)
    if c1 and c2:
        R = 6371
        lat1, lon1 = math.radians(c1[0]), math.radians(c1[1])
        lat2, lon2 = math.radians(c2[0]), math.radians(c2[1])
        dlat, dlon = lat2 - lat1, lon2 - lon1
        a = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
        dist = R * 2 * math.asin(math.sqrt(a)) * 1.3
        if dist > 800:
            hrs = dist / 800
            return {'mode': 'Plane', 'duration': f'{int(hrs)}h {int((hrs%1)*60)}m', 'distance_km': round(dist)}
        elif dist > 400:
            hrs = dist / 110
            return {'mode': 'Car', 'duration': f'{int(hrs)}h {int((hrs%1)*60)}m', 'distance_km': round(dist)}
        else:
            hrs = dist / 100
            return {'mode': 'Car', 'duration': f'{int(hrs)}h {int((hrs%1)*60)}m', 'distance_km': round(dist)}
    return None

def schedule_day_activities(activities_list, pace):
    """توزيع النشاطات على اليوم حسب مدة كل نشاط مع فترات راحة"""
    if pace == 'Relaxed':
        day_start, day_end, lunch_start = 9*60, 18*60, 13*60
    elif pace == 'Action-Packed':
        day_start, day_end, lunch_start = 8*60, 21*60, 13*60
    else:  # Balanced
        day_start, day_end, lunch_start = 8*60+30, 20*60, 12*60+30

    lunch_duration = 60
    travel_gap = 30  # وقت التنقل بين النشاطات

    scheduled = []
    current_time = day_start
    lunch_added = False

    for act in activities_list:
        cat = str(act.get('category', 'General'))
        duration = ACTIVITY_DURATION.get(cat, 90)

        # تعديل المدة حسب وتيرة السفر
        if pace == 'Relaxed':
            duration = int(duration * 1.3)
        elif pace == 'Action-Packed':
            duration = int(duration * 0.8)

        # إضافة فترة غداء تلقائياً
        if not lunch_added and current_time < lunch_start and current_time + duration > lunch_start:
            lunch_added = True
            current_time = lunch_start + lunch_duration

        # التحقق من عدم تجاوز نهاية اليوم
        if current_time + duration > day_end:
            break

        hours = current_time // 60
        mins = current_time % 60
        time_str = f'{hours:02d}:{mins:02d}'
        end_time = current_time + duration
        end_h, end_m = end_time // 60, end_time % 60
        end_str = f'{end_h:02d}:{end_m:02d}'

        act_copy = dict(act)
        act_copy['time'] = time_str
        act_copy['end_time'] = end_str
        act_copy['duration_min'] = duration
        scheduled.append(act_copy)

        current_time += duration + travel_gap

        # إضافة فترة غداء بعد النشاط إذا وصلنا لوقت الغداء
        if not lunch_added and current_time >= lunch_start:
            lunch_added = True
            current_time = max(current_time, lunch_start) + lunch_duration

    return scheduled

# ============================================================
# بناء جدول الرحلة
# ============================================================
def build_itinerary(profile):
    cities = profile['preferred_cities']
    total_days = profile['length_of_stay']

    # الحد الأقصى للنشاطات المرشحة لكل يوم (العدد الفعلي يتحدد حسب مدة كل نشاط)
    max_candidates = {'Relaxed': 4, 'Balanced': 6, 'Action-Packed': 8}
    activities_per_day = max_candidates.get(profile['travel_pace'], 6)

    num_cities = len(cities)
    if num_cities == 0:
        return None

    if num_cities == 1:
        days_per_city = {cities[0]: total_days}
    elif total_days >= num_cities:
        base = total_days // num_cities
        extra = total_days % num_cities
        days_per_city = {c: base + (1 if i < extra else 0) for i, c in enumerate(cities)}
    else:
        days_per_city = {c: 1 for i, c in enumerate(cities) if i < total_days}

    days = []
    used_hotels = set()
    used_attractions = set()
    day_num = 0
    city_order = list(days_per_city.keys())

    for city_idx, city in enumerate(city_order):
        city_days = days_per_city[city]
        attr_cities = CITY_TO_ATTR.get(city, [city])
        city_attr = df_attractions[df_attractions['city'].isin(attr_cities)].copy()
        if len(city_attr) > 0:
            city_attr = city_attr.sample(frac=1, random_state=42 + day_num).reset_index(drop=True)
        attr_idx = 0

        for d in range(city_days):
            day_num += 1
            day = {'day': day_num, 'city': city, 'activities': [], 'hotel': None, 'transport_from_prev': None}

            # النقل بين المدن
            if d == 0 and city_idx > 0:
                prev_city = city_order[city_idx - 1]
                transport = get_transport(prev_city, city)
                if transport:
                    day['transport_from_prev'] = {
                        'from': prev_city, 'to': city,
                        'mode': transport['mode'], 'duration': transport['duration'],
                        'distance_km': transport['distance_km'],
                    }

            # جمع نشاطات مرشحة لليوم
            day_candidates = []
            for slot in range(activities_per_day):
                if attr_idx < len(city_attr):
                    a = city_attr.iloc[attr_idx]
                    name = str(a['name'])
                    if name not in used_attractions:
                        cat = str(a['category']).replace('nan', 'General')
                        day_candidates.append({
                            'name': name,
                            'city': city,
                            'category': cat,
                        })
                        used_attractions.add(name)
                    attr_idx += 1
                else:
                    break

            # التوزيع الذكي حسب نوع كل نشاط
            scheduled = schedule_day_activities(day_candidates, profile['travel_pace'])
            day['activities'] = scheduled

            # الفندق
            hotels = df_hotels[df_hotels['city_en'].str.contains(city, case=False, na=False)]
            if len(hotels) == 0:
                hotels = df_hotels.head(50)

            budget = profile.get('daily_budget_sar', 500)
            if budget >= 800:
                pf = hotels[hotels['price_sar'] >= 400]
                if len(pf) > 0:
                    hotels = pf
            elif budget >= 300:
                pf = hotels[(hotels['price_sar'] >= 150) & (hotels['price_sar'] <= 1000)]
                if len(pf) > 0:
                    hotels = pf
            else:
                pf = hotels[hotels['price_sar'] <= 400]
                if len(pf) > 0:
                    hotels = pf

            not_used = hotels[~hotels['hotel_name'].isin(used_hotels)]
            if len(not_used) > 0:
                hotels = not_used
            hotels = hotels.sort_values('review_score', ascending=False)

            if len(hotels) > 0:
                h = hotels.iloc[0]
                day['hotel'] = {
                    'name': str(h['hotel_name']),
                    'rating': float(h['review_score']),
                    'price': float(h['price_sar']),
                }
                used_hotels.add(str(h['hotel_name']))

            if day['activities']:
                days.append(day)

    return {
        'profile': profile,
        'days': days,
        'total_attractions': sum(len(d['activities']) for d in days),
        'cities_visited': list(days_per_city.keys()),
        'days_per_city': days_per_city,
    }

# ============================================================
# توليد PDF
# ============================================================
def fix_arabic(text):
    if not text or not any('\u0600' <= c <= '\u06FF' for c in str(text)):
        return str(text)
    try:
        reshaped = arabic_reshaper.reshape(str(text))
        return get_display(reshaped)
    except:
        return str(text)

class ItineraryPDF(FPDF):
    def __init__(self):
        super().__init__()
        self.add_font('Noto', '', '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf')
        self.add_font('Noto', 'B', '/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf')
        self.add_font('Noto', 'I', '/usr/share/fonts/truetype/noto/NotoSans-Italic.ttf')
        self.add_font('Amiri', '', '/usr/share/fonts/opentype/fonts-hosny-amiri/Amiri-Regular.ttf')
        self.add_font('Amiri', 'B', '/usr/share/fonts/opentype/fonts-hosny-amiri/Amiri-Bold.ttf')

def generate_pdf_bytes(itinerary):
    pdf = ItineraryPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    p = itinerary['profile']

    # صفحة الغلاف
    pdf.add_page()
    pdf.set_fill_color(10, 22, 40)
    pdf.rect(0, 0, 210, 60, 'F')
    pdf.set_text_color(212, 165, 116)
    pdf.set_font('Noto', 'B', 26)
    pdf.set_y(15)
    pdf.cell(0, 12, 'TRIPSA Trip Plan', align='C', new_x='LMARGIN', new_y='NEXT')
    pdf.set_text_color(176, 196, 222)
    pdf.set_font('Noto', 'I', 11)
    pdf.cell(0, 8, 'Smart Tourism Recommendation System for Saudi Arabia', align='C', new_x='LMARGIN', new_y='NEXT')

    pdf.set_text_color(0, 0, 0)
    pdf.set_y(75)
    pdf.set_font('Noto', 'B', 14)
    pdf.cell(0, 10, 'Tourist Profile', new_x='LMARGIN', new_y='NEXT')
    pdf.set_font('Noto', '', 11)
    cities_str = ', '.join(itinerary.get('cities_visited', []))
    info_lines = [
        f"Duration: {p['length_of_stay']} days",
        f"Group Size: {p['group_size']}",
        f"Budget: {p.get('budget_label', 'N/A')} ({p.get('daily_budget_sar', 'N/A')} SAR/day)",
        f"Travel Pace: {p.get('travel_pace', 'N/A')}",
        f"Cities: {cities_str}",
        f"Accommodation: {p.get('accommodation_pref', 'N/A')}",
    ]
    for line in info_lines:
        pdf.cell(0, 7, line, new_x='LMARGIN', new_y='NEXT')

    # الأيام
    for day in itinerary['days']:
        pdf.add_page()

        if day.get('transport_from_prev'):
            t = day['transport_from_prev']
            pdf.set_fill_color(41, 128, 185)
            pdf.set_text_color(255, 255, 255)
            pdf.set_font('Noto', 'B', 10)
            pdf.cell(0, 8, f"  Travel: {t['from']} -> {t['to']} | {t['mode']} | {t['duration']} | {t['distance_km']} km", fill=True, new_x='LMARGIN', new_y='NEXT')
            pdf.ln(3)

        pdf.set_fill_color(10, 22, 40)
        pdf.set_text_color(212, 165, 116)
        pdf.set_font('Noto', 'B', 13)
        pdf.cell(0, 10, f"  Day {day['day']} - {day['city']}", fill=True, new_x='LMARGIN', new_y='NEXT')
        pdf.ln(3)

        pdf.set_text_color(0, 0, 0)
        pdf.set_font('Noto', 'B', 10)
        pdf.set_fill_color(230, 230, 250)
        pdf.cell(30, 8, 'Time', border=1, fill=True, align='C')
        pdf.cell(25, 8, 'Duration', border=1, fill=True, align='C')
        pdf.cell(65, 8, 'Attraction', border=1, fill=True)
        pdf.cell(40, 8, 'Category', border=1, fill=True, align='C')
        pdf.ln()

        pdf.set_font('Noto', '', 9)
        for act in day['activities']:
            time_str = act.get('time', '')
            end_str = act.get('end_time', '')
            time_range = f"{time_str}-{end_str}" if end_str else time_str
            dur_min = act.get('duration_min', 0)
            dur_label = f"{dur_min} min"

            pdf.cell(30, 7, time_range, border=1, align='C')
            pdf.cell(25, 7, dur_label, border=1, align='C')
            pdf.cell(65, 7, act['name'][:40], border=1)
            pdf.cell(40, 7, act['category'][:20], border=1, align='C')
            pdf.ln()

        if day.get('hotel'):
            pdf.ln(3)
            pdf.set_font('Noto', 'B', 10)
            pdf.cell(0, 7, 'Accommodation:', new_x='LMARGIN', new_y='NEXT')
            pdf.set_font('Amiri', '', 10)
            h = day['hotel']
            hotel_text = fix_arabic(h['name'])
            pdf.cell(0, 7, f"  {hotel_text}", new_x='LMARGIN', new_y='NEXT')
            pdf.set_font('Noto', '', 9)
            pdf.cell(0, 6, f"  Rating: {h['rating']} | Price: {h['price']} SAR/night", new_x='LMARGIN', new_y='NEXT')

    # صفحة الملخص
    pdf.add_page()
    pdf.set_font('Noto', 'B', 14)
    pdf.cell(0, 10, 'Trip Summary', new_x='LMARGIN', new_y='NEXT')
    pdf.set_font('Noto', '', 11)
    pdf.cell(0, 7, f"Total Days: {len(itinerary['days'])}", new_x='LMARGIN', new_y='NEXT')
    pdf.cell(0, 7, f"Total Attractions: {itinerary['total_attractions']}", new_x='LMARGIN', new_y='NEXT')
    cities_info = ', '.join([f"{c} ({d} days)" for c, d in itinerary.get('days_per_city', {}).items()])
    pdf.cell(0, 7, f"Cities: {cities_info}", new_x='LMARGIN', new_y='NEXT')

    transports = [d['transport_from_prev'] for d in itinerary['days'] if d.get('transport_from_prev')]
    if transports:
        pdf.ln(5)
        pdf.set_font('Noto', 'B', 12)
        pdf.cell(0, 8, 'Transportation Between Cities', new_x='LMARGIN', new_y='NEXT')
        pdf.set_font('Noto', 'B', 9)
        pdf.set_fill_color(200, 220, 240)
        pdf.cell(55, 7, 'Route', border=1, fill=True)
        pdf.cell(30, 7, 'Mode', border=1, fill=True, align='C')
        pdf.cell(30, 7, 'Duration', border=1, fill=True, align='C')
        pdf.cell(30, 7, 'Distance', border=1, fill=True, align='C')
        pdf.ln()
        pdf.set_font('Noto', '', 9)
        for t in transports:
            pdf.cell(55, 6, f"{t['from']} -> {t['to']}", border=1)
            pdf.cell(30, 6, t['mode'], border=1, align='C')
            pdf.cell(30, 6, t['duration'], border=1, align='C')
            pdf.cell(30, 6, f"{t['distance_km']} km", border=1, align='C')
            pdf.ln()

    return bytes(pdf.output())

# ============================================================
# واجهة المستخدم
# ============================================================

# العنوان الرئيسي
st.markdown("""
<div class="main-header">
    <h1>TRIPSA</h1>
    <p>Smart Tourism Recommendation System for Saudi Arabia</p>
    <p style="font-size: 0.9rem; color: #8899AA;">Plan your perfect trip based on your preferences</p>
</div>
""", unsafe_allow_html=True)

# الشريط الجانبي - خيارات الاستبيان
with st.sidebar:
    st.markdown("## 🗺️ Plan Your Trip")
    st.markdown("---")

    # مدة الإقامة
    stay_duration = st.selectbox(
        "How long will you stay?",
        options=['1-3 Days', '4-7 Days', '8-14 Days', 'More than 14 Days'],
        index=1
    )

    # عدد المسافرين
    group_size = st.selectbox(
        "Who are you traveling with?",
        options=['Solo Traveler', 'With a Partner', 'With Family', 'With Friends'],
        index=0
    )

    # الاهتمامات
    interests = st.multiselect(
        "What are your interests?",
        options=[
            'History & Culture',
            'Nature & Adventure',
            'Shopping & Entertainment',
            'Food & Cuisine',
            'Religious Tourism',
            'Beach & Relaxation',
            'Sports & Outdoor',
        ],
        default=['History & Culture']
    )

    # وتيرة السفر
    travel_pace = st.selectbox(
        "What is your travel pace?",
        options=['Relaxed', 'Balanced', 'Action-Packed'],
        index=1
    )

    # المأكولات
    cuisines = st.multiselect(
        "What cuisines do you prefer?",
        options=['Traditional Saudi', 'International', 'Street Food', 'Fine Dining'],
        default=['Traditional Saudi']
    )

    # الميزانية
    budget = st.selectbox(
        "What is your daily budget?",
        options=[
            'Budget - Less than 300 SAR',
            'Mid-Range - 300 to 800 SAR',
            'Luxury - More than 800 SAR'
        ],
        index=1
    )

    # المدن
    selected_cities = st.multiselect(
        "Which cities would you like to visit?",
        options=AVAILABLE_CITIES,
        default=['Riyadh']
    )

    # نوع الإقامة
    accommodation = st.selectbox(
        "Preferred accommodation type?",
        options=['Budget Hotel', 'Mid-Range Hotel', 'Luxury Hotel', 'Serviced Apartment', 'Resort', 'Hostel'],
        index=1
    )

    st.markdown("---")
    generate_btn = st.button("🚀 Generate Trip Plan", type="primary", use_container_width=True)

# ============================================================
# معالجة وعرض النتائج
# ============================================================
if generate_btn:
    if not selected_cities:
        st.error("Please select at least one city!")
    else:
        # تحويل الخيارات إلى ملف تعريف
        stay_map = {'1-3 Days': 2, '4-7 Days': 5, '8-14 Days': 10, 'More than 14 Days': 18}
        group_map = {'Solo Traveler': 1, 'With a Partner': 2, 'With Family': 4, 'With Friends': 4}

        if 'Luxury' in budget:
            daily_budget = 1000
            budget_label = 'Luxury'
        elif 'Mid' in budget:
            daily_budget = 500
            budget_label = 'Mid-Range'
        else:
            daily_budget = 200
            budget_label = 'Budget'

        profile = {
            'tourist_id': 'TOURIST_001',
            'length_of_stay': stay_map.get(stay_duration, 5),
            'group_size': group_map.get(group_size, 1),
            'travel_pace': travel_pace,
            'daily_budget_sar': daily_budget,
            'budget_label': budget_label,
            'preferred_cities': selected_cities,
            'accommodation_pref': accommodation,
        }

        with st.spinner('Building your personalized trip plan...'):
            itinerary = build_itinerary(profile)

        if itinerary and itinerary['days']:
            # ملخص سريع
            st.markdown("## Trip Overview")
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Days", len(itinerary['days']))
            with col2:
                st.metric("Cities", len(itinerary['cities_visited']))
            with col3:
                st.metric("Attractions", itinerary['total_attractions'])
            with col4:
                transports = [d['transport_from_prev'] for d in itinerary['days'] if d.get('transport_from_prev')]
                st.metric("Transfers", len(transports))

            st.markdown("---")

            # عرض كل يوم
            for day in itinerary['days']:
                # شريط النقل
                if day.get('transport_from_prev'):
                    t = day['transport_from_prev']
                    mode_icon = {'Plane': '✈️', 'Car': '🚗', 'Train': '🚄'}.get(t['mode'], '🚌')
                    st.markdown(f"""
                    <div class="transport-banner">
                        {mode_icon} <strong>Travel:</strong> {t['from']} → {t['to']} &nbsp;|&nbsp;
                        {t['mode']} &nbsp;|&nbsp; {t['duration']} &nbsp;|&nbsp; {t['distance_km']} km
                    </div>
                    """, unsafe_allow_html=True)

                # بطاقة اليوم
                with st.expander(f"📍 Day {day['day']} — {day['city']}", expanded=True):
                    # جدول الأنشطة
                    activities_data = []
                    for act in day['activities']:
                        time_range = f"{act['time']} - {act['end_time']}"
                        dur = f"{act['duration_min']} min"
                        activities_data.append({
                            'Time': time_range,
                            'Duration': dur,
                            'Attraction': act['name'],
                            'Category': act['category'],
                        })

                    if activities_data:
                        df_act = pd.DataFrame(activities_data)
                        st.dataframe(df_act, use_container_width=True, hide_index=True)

                    # الفندق
                    if day.get('hotel'):
                        h = day['hotel']
                        st.markdown(f"""
                        <div class="hotel-card">
                            🏨 <strong>Accommodation:</strong> {h['name']}<br>
                            ⭐ Rating: {h['rating']}/10 &nbsp;|&nbsp; 💰 {h['price']:.0f} SAR/night
                        </div>
                        """, unsafe_allow_html=True)

            # ملخص النقل
            transports = [d['transport_from_prev'] for d in itinerary['days'] if d.get('transport_from_prev')]
            if transports:
                st.markdown("---")
                st.markdown("## 🚀 Transportation Summary")
                transport_data = []
                for t in transports:
                    mode_icon = {'Plane': '✈️', 'Car': '🚗', 'Train': '🚄'}.get(t['mode'], '🚌')
                    transport_data.append({
                        'Route': f"{t['from']} → {t['to']}",
                        'Mode': f"{mode_icon} {t['mode']}",
                        'Duration': t['duration'],
                        'Distance': f"{t['distance_km']} km",
                    })
                st.dataframe(pd.DataFrame(transport_data), use_container_width=True, hide_index=True)

            # زر تحميل PDF
            st.markdown("---")
            st.markdown("## 📥 Download Trip Plan")
            pdf_bytes = generate_pdf_bytes(itinerary)
            st.download_button(
                label="Download PDF",
                data=pdf_bytes,
                file_name="TRIPSA_Trip_Plan.pdf",
                mime="application/pdf",
                type="primary",
                use_container_width=True,
            )

        else:
            st.error("Could not generate a trip plan. Please try different options.")

else:
    # الحالة الافتراضية
    st.markdown("""
    <div style="text-align: center; padding: 3rem 1rem; color: #666;">
        <h3>Welcome to TRIPSA Trip Planner</h3>
        <p>Use the sidebar to select your travel preferences, then click <strong>"Generate Trip Plan"</strong> to get your personalized itinerary.</p>
        <p style="font-size: 0.9rem; color: #999;">Powered by data from Visit Saudi, Booking.com, and Ministry of Tourism</p>
    </div>
    """, unsafe_allow_html=True)
